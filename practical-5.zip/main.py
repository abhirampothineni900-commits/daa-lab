import time

# User input
coins = list(map(int, input("Enter coin denominations: ").split()))
amount = int(input("Enter the amount: "))

# Start execution time
start_time = time.perf_counter()

# DP array
dp = [float('inf')] * (amount + 1)
dp[0] = 0

# Coin Change algorithm
for i in range(1, amount + 1):
    for coin in coins:
        if coin <= i:
            dp[i] = min(dp[i], dp[i - coin] + 1)

# End execution time
end_time = time.perf_counter()

# Output
if dp[amount] == float('inf'):
    print("Amount cannot be formed using the given coins.")
else:
    print("Minimum number of coins:", dp[amount])

print("Execution time:", end_time - start_time, "seconds")