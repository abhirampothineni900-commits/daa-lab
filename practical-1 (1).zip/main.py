import time

# Function to partition the array
def partition(arr, low, high):
    pivot = arr[high]  # Choose the last element as pivot
    i = low - 1

    for j in range(low, high):
        if arr[j] <= pivot:
            i += 1
            arr[i], arr[j] = arr[j], arr[i]

    # Place pivot in its correct position
    arr[i + 1], arr[high] = arr[high], arr[i + 1]
    return i + 1


# Function to perform Quick Sort
def quick_sort(arr, low, high):
    if low < high:
        pi = partition(arr, low, high)

        # Sort elements before and after partition
        quick_sort(arr, low, pi - 1)
        quick_sort(arr, pi + 1, high)


# User Input
n = int(input("Enter the number of elements: "))

arr = []
print("Enter the elements:")
for i in range(n):
    element = int(input())
    arr.append(element)

# Measure execution time
start_time = time.perf_counter()

quick_sort(arr, 0, n - 1)

end_time = time.perf_counter()

# Display Results
print("\nSorted Array:", arr)
print("Execution Time: {:.10f} seconds".format(end_time - start_time))

# Time Complexity
print("\nTime Complexity:")
print("Best Case    : O(n log n)")
print("Average Case : O(n log n)")
print("Worst Case   : O(n^2)")

# Space Complexity
print("\nSpace Complexity:")
print("Average Case : O(log n)")
print("Worst Case   : O(n)")
